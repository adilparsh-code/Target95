"use client";

import { useState, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import SectionLink from "./SectionLink";
import Button from "./ui/Button";
import Container from "./ui/Container";
import { useAuth } from "@/context/AuthContext";
import StudentGlobalSearch from "./StudentGlobalSearch";
import { MagnifyingGlassIcon, Bars3Icon, XMarkIcon, SunIcon, MoonIcon } from "@heroicons/react/24/outline";

const links = [
  { href: "/daily-challenge", label: "Daily Challenge", description: "Earn XP", icon: "DC" },
  { href: "/rewards", label: "Rewards", description: "Badges", icon: "XP" },
  { href: "/my-learning", label: "My Learning", description: "Roadmap", icon: "ML" },
  { href: "/", label: "Home", description: "Overview", icon: "🏠" },
  { href: "/dashboard", label: "Dashboard", description: "Progress", icon: "📊" },
  { href: "/study", label: "Study", description: "Chapters", icon: "📖" },
  { href: "/java", label: "Practice", description: "Questions", icon: "📘" },
  { href: "/mock-test", label: "Mock Tests", description: "Timed", icon: "📝" },
  { href: "/question-bank", label: "Questions", description: "Bank", icon: "📚" },
  { href: "/analytics", label: "Analytics", description: "Stats", icon: "📈" },
  { href: "/ai-tutor", label: "AI Tutor", description: "Help", icon: "🤖" },
];

export default function Navbar() {
  const { user, logout, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    // Check localStorage or system preference on mount
    const savedDarkMode = localStorage.getItem('darkMode');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedDarkMode === 'true') {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    } else if (savedDarkMode === 'false') {
      setDarkMode(false);
      document.documentElement.classList.remove('dark');
    } else if (prefersDark) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  // Handle Escape key to close mobile menu
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
      if (e.key === 'Escape' && searchOpen) {
        setSearchOpen(false);
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [mobileMenuOpen, searchOpen]);

  // Trap focus inside mobile menu when open
  useEffect(() => {
    if (mobileMenuOpen) {
      const focusableElements = document.querySelectorAll(
        '.xl\\:hidden [href], .xl\\:hidden button, .xl\\:hidden [tabindex]:not([tabindex="-1"])'
      );
      const firstFocusable = focusableElements[0];
      const lastFocusable = focusableElements[focusableElements.length - 1];

      const handleTab = (e) => {
        if (e.key === 'Tab') {
          if (e.shiftKey && document.activeElement === firstFocusable) {
            e.preventDefault();
            lastFocusable?.focus();
          } else if (!e.shiftKey && document.activeElement === lastFocusable) {
            e.preventDefault();
            firstFocusable?.focus();
          }
        }
      };

      document.addEventListener('keydown', handleTab);
      firstFocusable?.focus();
      
      return () => document.removeEventListener('keydown', handleTab);
    }
  }, [mobileMenuOpen]);

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem('darkMode', newDarkMode.toString());
    
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleLogout = async () => {
    const result = await logout();
    if (result.success) router.push("/");
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-gray-200 bg-white/95 dark:border-gray-700 dark:bg-gray-900/95 shadow-sm backdrop-blur supports-[backdrop-filter]:bg-white/80 dark:supports-[backdrop-filter]:bg-gray-900/80">
      {/* Skip link for keyboard navigation */}
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:rounded-lg focus:bg-blue-600 focus:px-4 focus:py-2 focus:text-white focus:shadow-lg"
      >
        Skip to main content
      </a>
      
      <Container>
        <div className="flex min-h-16 items-center justify-between gap-3 py-2 sm:min-h-[72px] sm:py-3">
          {/* Logo */}
          <Link href="/" className="text-xl sm:text-2xl lg:text-3xl font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors duration-300 shrink-0">
            🎯 Target95+
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden xl:flex min-w-0 flex-1 items-center justify-center gap-1">
            {links.map((link) => {
              const isActive = pathname === link.href || pathname.startsWith(link.href + '/') || (link.href !== '/' && pathname.includes(link.href));
              const linkClasses = `rounded-lg px-2 py-2 text-sm font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                isActive 
                  ? "bg-blue-100 text-blue-700 dark:bg-gray-800 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400" 
                  : "text-gray-600 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-800 hover:text-blue-700 dark:hover:text-blue-300 border-b-2 border-transparent"
              }`;
              return (
                <Link 
                  key={link.href} 
                  href={link.href} 
                  className={linkClasses.trim()}
                  aria-current={isActive ? "page" : undefined}
                >
                  {link.label}
                </Link>
              );
            })}
          </div>

          {/* Right section: search + dark mode + auth */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={toggleDarkMode}
              className="rounded-xl border border-gray-300 bg-white dark:border-gray-600 dark:bg-gray-800 p-2 text-gray-700 dark:text-gray-200 transition hover:border-gray-400 dark:hover:border-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700"
              aria-label="Toggle dark mode"
            >
              {darkMode ? <SunIcon className="h-5 w-5" aria-hidden="true" /> : <MoonIcon className="h-5 w-5" aria-hidden="true" />}
            </button>
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="rounded-xl border border-gray-300 bg-white dark:border-gray-600 dark:bg-gray-800 p-2 text-gray-700 dark:text-gray-200 transition hover:border-gray-400 dark:hover:border-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700"
              aria-label="Open search"
            >
              <MagnifyingGlassIcon className="h-5 w-5" aria-hidden="true" />
            </button>

            {loading ? (
              <div className="h-10 w-20 bg-gray-200 animate-pulse rounded-md hidden sm:block"></div>
            ) : user ? (
              <div className="hidden sm:flex items-center gap-2">
                <Link href="/profile" className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-100 text-sm font-bold text-blue-700" aria-label="Open profile">{(user.fullName || user.email || "T").slice(0, 1).toUpperCase()}</Link>
                <span className="text-sm font-medium text-gray-700 truncate max-w-[100px]">
                  {user.fullName || user.email}
                </span>
                <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                  {user.role}
                </span>
                <Button variant="outline" onClick={handleLogout} className="text-sm">
                  Logout
                </Button>
              </div>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Link href="/login">
                  <Button className="text-sm">Login</Button>
                </Link>
                <Link href="/register">
                  <Button variant="outline" className="text-sm">Register</Button>
                </Link>
              </div>
            )}

            {/* Mobile menu button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden rounded-xl border border-gray-300 bg-white p-2 text-gray-700 transition hover:border-gray-400 hover:bg-gray-50"
              aria-label="Toggle menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? (
                <XMarkIcon className="h-5 w-5" aria-hidden="true" />
              ) : (
                <Bars3Icon className="h-5 w-5" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </Container>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div 
          className="xl:hidden fixed inset-0 top-16 bg-black/50 z-40"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Mobile Menu Dropdown */}
      <div
        className={`xl:hidden fixed inset-x-0 top-16 z-50 overflow-hidden transition-all duration-300 ease-in-out ${
          mobileMenuOpen ? "max-h-[calc(100dvh-64px)] opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="max-h-[calc(100dvh-64px)] overflow-y-auto border-t border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 px-4 py-4 space-y-2 overscroll-contain">
          {links.map((link) => {
            const isActive = pathname === link.href || pathname.startsWith(link.href + '/') || (link.href !== '/' && pathname.includes(link.href));
            return (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-3 py-3 rounded-xl border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                  isActive 
                    ? "border-blue-500/50 bg-blue-50 dark:bg-gray-800 shadow-md" 
                    : "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 hover:-translate-y-0.5 hover:border-blue-400/50 hover:shadow-sm"
                }`}
                aria-current={isActive ? "page" : undefined}
              >
                <span className="text-xl flex-shrink-0" aria-hidden="true">{link.icon}</span>
                <div className="min-w-0 flex-1">
                  <p className={`font-semibold text-sm ${isActive ? "text-blue-700 dark:text-blue-400" : "text-gray-900 dark:text-gray-100"}`}>{link.label}</p>
                  {link.description && <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{link.description}</p>}
                </div>
                <span className={`text-lg transition-all duration-300 ${isActive ? "text-blue-500 translate-x-1" : "text-gray-400 group-hover:translate-x-1 group-hover:text-blue-500"}`} aria-hidden="true">→</span>
              </Link>
            );
          })}
          <div className="border-t border-gray-100 pt-4 mt-4 space-y-2">
            {loading ? (
              <div className="h-10 bg-gray-200 animate-pulse rounded-md"></div>
            ) : user ? (
              <div className="space-y-2">
                <Link href="/profile" onClick={() => setMobileMenuOpen(false)} className="block rounded-lg px-2 py-2 text-sm font-semibold text-blue-700 hover:bg-blue-50">Profile</Link>
                <Link href="/settings" onClick={() => setMobileMenuOpen(false)} className="block rounded-lg px-2 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">Settings</Link>
                <div className="flex items-center gap-2 px-2">
                  <span className="text-sm font-medium text-gray-700 truncate">
                    {user.fullName || user.email}
                  </span>
                  <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                    {user.role}
                  </span>
                </div>
                <Button variant="outline" onClick={handleLogout} className="w-full">
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <Link href="/login" onClick={() => setMobileMenuOpen(false)}>
                  <Button className="w-full">Login</Button>
                </Link>
                <Link href="/register" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="outline" className="w-full">Register</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      <StudentGlobalSearch isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </nav>
  );
}

// Add id to main content areas for skip link
// This is used in pages that use this Navbar
export const NavbarSkipLinkId = 'main-content';